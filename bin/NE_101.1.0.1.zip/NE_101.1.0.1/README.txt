bootloader.bin               0x0 
partition-table.bin          0x8000
NE_101.1.0.1.bin             0x100000


bootloader.bin               0x0 
partition-table.bin          0x8000
NE101_PIR.bin                0x100000

